<?php

namespace App\Http\Controllers\Api;

use App\Events\StoreFavorRequested;
use App\Http\Controllers\Controller;
use App\Models\Favor;
use App\Models\FavorBid;
use App\Services\FcmService;
use App\Support\DeliveryPricing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StoreFavorController extends Controller
{
    public function create(Request $request)
    {
        $seller = auth()->guard('seller')->user();
        if (!$seller) {
            return apiResponse('unauthorized', 'error', ['No autorizado']);
        }

        $validator = Validator::make($request->all(), [
            'description'      => 'required|string|max:1000',
            'pickup_address'   => 'required|string|max:500',
            'pickup_lat'       => 'nullable|numeric',
            'pickup_lng'       => 'nullable|numeric',
            'delivery_address' => 'required|string|max:500',
            'delivery_lat'     => 'nullable|numeric',
            'delivery_lng'     => 'nullable|numeric',
        ]);

        if ($validator->fails()) {
            return apiResponse('validation_error', 'error', $validator->errors()->all());
        }

        $store = $seller->stores->first();
        [$pickupLat, $pickupLng] = DeliveryPricing::coordinateFromRequest(
            $request,
            ['pickup_lat'],
            ['pickup_lng']
        );
        [$deliveryLat, $deliveryLng] = DeliveryPricing::deliveryCoordinatesFromRequest($request);
        $pickupLat = $pickupLat ?? ($store?->latitude !== null ? (float) $store->latitude : null);
        $pickupLng = $pickupLng ?? ($store?->longitude !== null ? (float) $store->longitude : null);

        $estimate = DeliveryPricing::estimateForFavor($pickupLat, $pickupLng, $deliveryLat, $deliveryLng);
        $deliveryFee = $estimate['delivery_fee'];
        $orderNo = 'STF-' . now()->format('Ymd') . '-' . strtoupper(\Str::random(6));
        $pinCode = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);

        $favor = Favor::create([
            'order_no'         => $orderNo,
            'user_id'          => 0,
            'seller_id'        => $seller->id,
            'source_type'      => 'seller',
            'type'             => 'send',
            'description'      => $request->description,
            'pickup_address'   => $request->pickup_address,
            'pickup_lat'       => $pickupLat,
            'pickup_lng'       => $pickupLng,
            'delivery_address' => $request->delivery_address,
            'delivery_lat'     => $deliveryLat,
            'delivery_lng'     => $deliveryLng,
            'delivery_fee'     => $deliveryFee,
            'total'            => $deliveryFee,
            'status'           => 'searching_courier',
            'pin_code'         => $pinCode,
        ]);

        $favor->pin()->create(['pin_code' => $pinCode]);

        // Broadcast to nearby couriers and admin
        broadcast(new StoreFavorRequested($favor->load('seller')));

        // FCM push to all non-ride couriers
        FcmService::sendToAllCouriers('Tienda solicita repartidor', $seller->stores->first()?->name . ' necesita un repartidor - ' . ($request->description ?? 'Favor'), ['favor_id' => (string) $favor->id, 'order_no' => $favor->order_no, 'type' => 'store_favor']);

        return apiResponse('store_favor_created', 'success', ['Solicitud enviada a repartidores cercanos'], [
            'favor' => $favor->load('bids'),
        ]);
    }

    public function myFavors(Request $request)
    {
        $seller = auth()->guard('seller')->user();
        $favors = Favor::where('seller_id', $seller->id)
            ->with('courier', 'bids')
            ->orderBy('id', 'desc')
            ->paginate($request->per_page ?? 20);

        return apiResponse('store_favors', 'success', ['Tus solicitudes'], [
            'favors' => $favors,
        ]);
    }

    public function detail($id)
    {
        $seller = auth()->guard('seller')->user();
        $favor = Favor::where('seller_id', $seller->id)
            ->with('courier', 'bids.courier', 'messages')
            ->findOrFail($id);

        return apiResponse('favor_detail', 'success', ['Detalle'], [
            'favor' => $favor,
        ]);
    }

    public function cancel($id)
    {
        $seller = auth()->guard('seller')->user();
        $favor = Favor::where('seller_id', $seller->id)
            ->whereIn('status', ['searching_courier', 'accepted'])
            ->findOrFail($id);

        $favor->update(['status' => 'cancelled', 'cancelled_at' => now()]);
        return apiResponse('cancelled', 'success', ['Solicitud cancelada']);
    }

    public function bids($id)
    {
        $seller = auth()->guard('seller')->user();
        $favor = Favor::where('seller_id', $seller->id)->findOrFail($id);
        $bids  = $favor->bids()->with('courier')->orderBy('bid_amount')->get();

        return apiResponse('bids', 'success', ['Ofertas'], ['bids' => $bids]);
    }

    public function acceptBid($favorId, $bidId)
    {
        $seller = auth()->guard('seller')->user();
        $favor = Favor::where('seller_id', $seller->id)
            ->where('status', 'searching_courier')
            ->findOrFail($favorId);

        $bid = $favor->bids()->where('id', $bidId)->firstOrFail();
        $bid->update(['status' => 'accepted']);
        $favor->bids()->where('id', '!=', $bidId)->update(['status' => 'rejected']);

        $favor->update([
            'status'            => 'accepted',
            'courier_id'        => $bid->courier_id,
            'accepted_bid_id'   => $bid->id,
            'total'             => $bid->bid_amount,
            'courier_assigned_at' => now(),
        ]);

        broadcast(new \App\Events\FavorStatusUpdated($favor, 'courier_accepted'));

        return apiResponse('bid_accepted', 'success', ['Repartidor asignado']);
    }
}
